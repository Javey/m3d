/**
 * Created with JetBrains PhpStorm.
 * User: zoujiawei
 * Date: 13-12-17
 * Time: 下午7:50
 * To change this template use File | Settings | File Templates.
 */

define(['angular'], function() {
    return ['$scope', 'branch', function($scope, branch) {
        // 数据缓存
        var cache = {};

    }];
});